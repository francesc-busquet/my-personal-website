from flask import Flask, request, render_template, redirect, url_for
import os
from dotenv import load_dotenv
import psycopg
import re 

load_dotenv()

db_user = os.getenv('DB_USER')
db_password = os.getenv('DB_PASSWORD')
db_host = os.getenv('DB_HOST')
db_port = os.getenv('DB_PORT')
db_name = os.getenv('DB_NAME')

def connect_to_database() -> psycopg.Connection | None:
    try:
        conn = psycopg.connect(
            dbname=db_name,
            user=db_user,
            password=db_password,
            host=db_host,
            port=db_port
        )
        return conn
    except Exception as e:
        print(e)

def is_valid_url(url: str) -> bool:
    pattern = r"^(https?:\/\/)?(www\.)?[a-zA-Z0-9]+\.[a-zA-Z]+$"
    return bool(re.fullmatch(pattern, url))

def insert_url_into_database(url: str) -> None:
    try:
        conn = connect_to_database()
        cur = conn.cursor()
        cur.execute("INSERT INTO registered_urls (url) VALUES (%s)", (url,))
        conn.commit()
    except Exception as e:
        print("Error inserting URL into the database:", e)
    finally:
        conn.close()

def process_url(url: str) -> str:
    if is_valid_url(url):
        insert_url_into_database(url)
        confirmation_message = "You have successfully registered the following URL: " + url
    else:
        confirmation_message = "The URL you entered is not valid. Please check the format and try again."
    return confirmation_message

def get_top_registered_urls() -> List[Tuple[str, int]] | None:
    try:
        conn = connect_to_database()
        cur = conn.cursor()
        cur.execute("""
            SELECT url, COUNT(*) as count
            FROM registered_urls
            GROUP BY url
            ORDER BY count DESC
            LIMIT 10;
        """)
        top_registered_urls = cur.fetchall()
        return top_registered_urls
    except Exception as e:
        print(f"Error retrieving the URLs: {e}")
    finally:
        if conn:
            conn.close()

app = Flask(__name__)

@app.cli.command("init-db-table")
def create_table() -> None:
    try:
        conn = connect_to_database()
        cur = conn.cursor()

        cur.execute("""
            CREATE TABLE IF NOT EXISTS registered_urls (
                id SERIAL PRIMARY KEY,
                url TEXT
            )
        """)

        conn.commit()
        print("create_table function executed correctly")
    except Exception as e:
        print(e)
    finally:
        conn.close()

@app.route("/", methods=['GET', 'POST'])
def home():
    if request.method == 'POST':
        url = request.form.get('urlInput')
        confirmation_message = process_url(url)
        return redirect(url_for('display_url', url=confirmation_message))
    else:
        return render_template('index.html')

@app.route("/display_url/<path:url>", methods=['GET', 'POST'])
def display_url(url: str | None = None):
    if url:
        if request.method == 'POST':
            url2 = request.form.get('urlInput')
            confirmation_message = process_url(url2)
            return redirect(url_for('display_url', url=confirmation_message))
        else:
            return render_template('index.html', url=url)
    else:
        return redirect(url_for('home'))

@app.route("/popular", methods=['GET'])
def top_favorite_websites_page():
    top_registered_urls = get_top_registered_urls()
    return render_template('popular.html', top_registered_urls=top_registered_urls)

if __name__ == "__main__":
    app.run(debug=True)